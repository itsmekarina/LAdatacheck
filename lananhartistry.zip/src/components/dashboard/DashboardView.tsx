import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  BookOpen,
  ArrowRight,
  AlertTriangle,
  Brain,
  Users,
  Compass,
  History,
  TrendingUp,
  FileEdit,
  CheckCircle2,
  Share2,
  Lock,
  Globe,
  Link2,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    stories,
    activeStory,
    openChapterForTranslation,
    setCurrentView,
    warningsCount,
    setShowWhatChangedModal,
    setShowShareModal,
    currentUser,
  } = useApp();

  const getGreeting = () => {
    const name = currentUser?.displayName || 'Lan Anh';
    const hour = new Date().getHours();
    if (hour < 12) return `Chào buổi sáng, ${name}`;
    if (hour < 18) return `Chào buổi chiều, ${name}`;
    return `Chào buổi tối, ${name}`;
  };

  const getPrivacyBadge = (privacy: string) => {
    switch (privacy) {
      case 'public':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            <Globe className="w-2.5 h-2.5" />
            <span>Công khai</span>
          </span>
        );
      case 'link_only':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-sky-50 text-sky-700 dark:bg-sky-950/40 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
            <Link2 className="w-2.5 h-2.5" />
            <span>Có link</span>
          </span>
        );
      case 'public_memory_only':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-cyan-50 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800">
            <Brain className="w-2.5 h-2.5" />
            <span>Shared TM</span>
          </span>
        );
      case 'private':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-[#E8F7FA] text-[#2E6C7B] dark:bg-[#172D35] dark:text-[#77CBDA] border border-[#D7EDF2] dark:border-[#1F3A44]">
            <Lock className="w-2.5 h-2.5" />
            <span>Riêng tư</span>
          </span>
        );
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-200">
      
      {/* Hero Greeting & Quick Continue in Pastel Blue */}
      <div className="relative overflow-hidden p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#E8F7FA] via-[#F4FBFD] to-[#E8F7FA] dark:from-[#172D35] dark:via-[#122228] dark:to-[#172D35] border border-[#D7EDF2] dark:border-[#1F3A44] shadow-xs">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#B3EBF2] dark:bg-[#2E6C7B] text-[#2E6C7B] dark:text-[#E8F7FA] text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-[#2E6C7B] dark:text-[#77CBDA]" />
              <span>LanAnhArtistry — Second Brain for Translators</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#26343B] dark:text-[#ECF7F9] tracking-tight">
              {getGreeting()}
            </h1>
            <p className="text-xs sm:text-sm text-[#647780] dark:text-[#8AA4AE] max-w-xl leading-relaxed">
              Biến mỗi tác phẩm thành một bộ nhớ văn học thứ hai: lưu trữ nguyên tác song song, giữ vững đại từ xưng hô, ghi nhớ thuật ngữ và phát hiện mọi điểm bất nhất.
            </p>
          </div>

          {activeStory && (
            <div className="shrink-0 p-5 rounded-2xl bg-white/95 dark:bg-[#122228]/95 border border-[#D7EDF2] dark:border-[#1F3A44] shadow-md flex flex-col gap-3 min-w-[280px]">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#647780] font-medium">Tiếp tục phiên dịch</span>
                {getPrivacyBadge(activeStory.privacy)}
              </div>
              <div>
                <h3 className="font-serif font-bold text-[#26343B] dark:text-[#ECF7F9] text-base truncate max-w-[240px]">
                  {activeStory.title}
                </h3>
                <p className="text-xs text-[#647780] mt-0.5">
                  {activeStory.id === 'story-vantien-01' ? 'Chương 36 — Đoạn Tuyệt' : `Đang dịch chương ${activeStory.translatedChapters + 1}`}
                </p>
              </div>
              <button
                onClick={() => {
                  if (activeStory.id === 'story-vantien-01') {
                    openChapterForTranslation(activeStory.id, 'chap-36-vantien', true);
                  } else {
                    setCurrentView('translate');
                  }
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold bg-[#2E6C7B] hover:bg-[#1A4954] text-white shadow-xs transition-all cursor-pointer"
              >
                <span>Vào bàn dịch (Workspace)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Grid: Recently Translated & Things to Review */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recently Translated Stories (2 Columns) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#647780] dark:text-[#8AA4AE] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#2E6C7B] dark:text-[#77CBDA]" />
              <span>Tác phẩm đang dịch ({stories.length})</span>
            </h2>
            <button
              onClick={() => setCurrentView('stories')}
              className="text-xs text-[#2E6C7B] dark:text-[#77CBDA] hover:underline font-semibold"
            >
              Xem tất cả
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {stories.map((story) => {
              const progressPct = Math.round(
                (story.translatedChapters / (story.totalChapters || 1)) * 100
              );
              return (
                <div
                  key={story.id}
                  className="p-5 rounded-2xl bg-white dark:bg-[#122228] border border-[#D7EDF2] dark:border-[#1F3A44] hover:border-[#77CBDA] hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between mb-3">
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-[#E8F7FA] dark:bg-[#172D35] text-[#2E6C7B] dark:text-[#77CBDA] border border-[#D7EDF2] dark:border-[#1F3A44]">
                        {story.sourceLanguage.toUpperCase()} → VI
                      </span>
                      <div className="flex items-center gap-2">
                        {getPrivacyBadge(story.privacy)}
                        <span className="text-xs font-semibold text-[#2E6C7B] dark:text-[#77CBDA]">
                          {progressPct}%
                        </span>
                      </div>
                    </div>

                    <h3
                      onClick={() => {
                        if (story.id === 'story-vantien-01') {
                          openChapterForTranslation(story.id, 'chap-36-vantien', false);
                        } else {
                          setCurrentView('translate');
                        }
                      }}
                      className="font-serif font-bold text-base text-[#26343B] dark:text-[#ECF7F9] hover:text-[#2E6C7B] dark:hover:text-[#77CBDA] cursor-pointer transition-colors"
                    >
                      {story.title}
                    </h3>
                    <p className="text-xs text-[#647780] line-clamp-2 mt-1">
                      {story.description}
                    </p>
                  </div>

                  <div className="space-y-2 pt-4">
                    <div className="w-full bg-[#E8F7FA] dark:bg-[#172D35] h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-[#2E6C7B] dark:bg-[#77CBDA] h-full rounded-full transition-all duration-300"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-[#647780]">
                      <span>Đã dịch: {story.translatedChapters}/{story.totalChapters} chương</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setShowShareModal(true)}
                          className="hover:text-[#2E6C7B] dark:hover:text-[#77CBDA] cursor-pointer flex items-center gap-0.5"
                          title="Cài đặt quyền chia sẻ"
                        >
                          <Share2 className="w-3 h-3" />
                          <span>Chia sẻ</span>
                        </button>
                        <button
                          onClick={() => {
                            if (story.id === 'story-vantien-01') {
                              openChapterForTranslation(story.id, 'chap-36-vantien', false);
                            } else {
                              setCurrentView('translate');
                            }
                          }}
                          className="text-[#2E6C7B] dark:text-[#77CBDA] font-semibold hover:underline inline-flex items-center gap-1 cursor-pointer"
                        >
                          Dịch tiếp →
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Things to Review (1 Column) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#647780] dark:text-[#8AA4AE] flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Things to Review</span>
            </h2>
            <button
              onClick={() => setCurrentView('consistency_warnings')}
              className="text-xs text-[#2E6C7B] dark:text-[#77CBDA] hover:underline font-semibold"
            >
              Review Center
            </button>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-[#122228] border border-[#D7EDF2] dark:border-[#1F3A44] space-y-3 shadow-xs">
            {warningsCount.total > 0 ? (
              <>
                <p className="text-xs text-[#647780]">
                  Phát hiện một số điểm nghi vấn cần bạn xác nhận trong chapter hiện tại:
                </p>

                <div
                  onClick={() => setCurrentView('consistency_warnings')}
                  className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 cursor-pointer hover:scale-[1.01] transition-transform flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-rose-500 font-bold">⚠️</span>
                    <div>
                      <p className="text-xs font-semibold text-rose-900 dark:text-rose-300">
                        {warningsCount.translation || 1} Translation Inconsistency
                      </p>
                      <p className="text-[11px] text-rose-700/80 dark:text-rose-400">
                        "宗门" lệch quy chuẩn: dùng "môn phái" thay vì "tông môn"
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-rose-500" />
                </div>

                <div
                  onClick={() => setCurrentView('pronoun_warnings')}
                  className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 cursor-pointer hover:scale-[1.01] transition-transform flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-amber-500 font-bold">⚠️</span>
                    <div>
                      <p className="text-xs font-semibold text-amber-900 dark:text-amber-300">
                        {warningsCount.pronoun || 1} Pronoun Deviation
                      </p>
                      <p className="text-[11px] text-amber-700/80 dark:text-amber-400">
                        Nguyễn An → Lâm Phong: đổi xưng hô từ huynh sang ta
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-amber-500" />
                </div>

                <div
                  onClick={() => setCurrentView('bible')}
                  className="p-3 rounded-xl bg-[#E8F7FA] dark:bg-[#172D35] border border-[#D7EDF2] dark:border-[#1F3A44] cursor-pointer hover:scale-[1.01] transition-transform flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-[#2E6C7B] dark:text-[#77CBDA] font-bold">📖</span>
                    <div>
                      <p className="text-xs font-semibold text-[#2E6C7B] dark:text-[#77CBDA]">
                        1 Story Bible Rule Reminder
                      </p>
                      <p className="text-[11px] text-[#647780]">
                        Cấm dùng "sư phụ", giữ vững "sư tôn" cho Tiêu Dao Tử
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-[#2E6C7B]" />
                </div>
              </>
            ) : (
              <div className="py-8 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <p className="text-xs font-medium text-[#26343B] dark:text-[#ECF7F9]">
                  Mọi thứ đều nhất quán!
                </p>
                <p className="text-[11px] text-[#647780]">
                  Không có cảnh báo thuật ngữ hay xưng hô nào tồn đọng.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Activity Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wider text-[#647780] dark:text-[#8AA4AE] flex items-center gap-2">
            <History className="w-4 h-4 text-[#647780]" />
            <span>Recent Activity & Knowledge Delta</span>
          </h2>
          <button
            onClick={() => setShowWhatChangedModal(true)}
            className="text-xs text-[#2E6C7B] dark:text-[#77CBDA] hover:underline font-semibold"
          >
            What changed since last time?
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div
            onClick={() => setCurrentView('tm')}
            className="p-4 rounded-2xl bg-white dark:bg-[#122228] border border-[#D7EDF2] dark:border-[#1F3A44] cursor-pointer hover:border-[#77CBDA] transition-all flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-[#E8F7FA] text-[#2E6C7B] dark:bg-[#172D35] dark:text-[#77CBDA] flex items-center justify-center shrink-0">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-[#647780]">Translation Memory</p>
              <p className="text-lg font-bold text-[#26343B] dark:text-[#ECF7F9]">+12</p>
            </div>
          </div>

          <div
            onClick={() => setCurrentView('characters')}
            className="p-4 rounded-2xl bg-white dark:bg-[#122228] border border-[#D7EDF2] dark:border-[#1F3A44] cursor-pointer hover:border-[#77CBDA] transition-all flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-[#E8F7FA] text-[#2E6C7B] dark:bg-[#172D35] dark:text-[#77CBDA] flex items-center justify-center shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-[#647780]">Characters</p>
              <p className="text-lg font-bold text-[#26343B] dark:text-[#ECF7F9]">+4</p>
            </div>
          </div>

          <div
            onClick={() => setCurrentView('plot_timeline')}
            className="p-4 rounded-2xl bg-white dark:bg-[#122228] border border-[#D7EDF2] dark:border-[#1F3A44] cursor-pointer hover:border-[#77CBDA] transition-all flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-[#E8F7FA] text-[#2E6C7B] dark:bg-[#172D35] dark:text-[#77CBDA] flex items-center justify-center shrink-0">
              <History className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-[#647780]">Plot Events</p>
              <p className="text-lg font-bold text-[#26343B] dark:text-[#ECF7F9]">+5</p>
            </div>
          </div>

          <div
            onClick={() => setCurrentView('terms')}
            className="p-4 rounded-2xl bg-white dark:bg-[#122228] border border-[#D7EDF2] dark:border-[#1F3A44] cursor-pointer hover:border-[#77CBDA] transition-all flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-[#E8F7FA] text-[#2E6C7B] dark:bg-[#172D35] dark:text-[#77CBDA] flex items-center justify-center shrink-0">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-[#647780]">Terminology</p>
              <p className="text-lg font-bold text-[#26343B] dark:text-[#ECF7F9]">+4</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
