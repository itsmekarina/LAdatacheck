import {
  Story,
  Chapter,
  TranslationMemory,
  VocabularyItem,
  TerminologyItem,
  SharedContribution,
  AuditLog,
  SyncStatus,
  ConflictData,
} from '../types';
import { getSupabaseClient, isSupabaseConfigured } from './supabase';

type SyncListener = (status: SyncStatus, lastSynced?: string) => void;
type ConflictListener = (conflict: ConflictData | null) => void;

class CloudSyncManager {
  private status: SyncStatus = 'idle';
  private lastSyncedTime: string = '';
  private syncListeners: Set<SyncListener> = new Set();
  private conflictListeners: Set<ConflictListener> = new Set();
  private autosaveTimer: any = null;
  private pendingChanges: {
    stories?: Story[];
    chapters?: Chapter[];
    translationMemory?: TranslationMemory[];
    vocabulary?: VocabularyItem[];
    terminology?: TerminologyItem[];
  } = {};

  constructor() {
    this.lastSyncedTime = localStorage.getItem('lananh_last_synced') || new Date().toISOString();
  }

  public subscribeStatus(listener: SyncListener): () => void {
    this.syncListeners.add(listener);
    listener(this.status, this.lastSyncedTime);
    return () => this.syncListeners.delete(listener);
  }

  public subscribeConflict(listener: ConflictListener): () => void {
    this.conflictListeners.add(listener);
    return () => this.conflictListeners.delete(listener);
  }

  private setStatus(status: SyncStatus) {
    this.status = status;
    this.syncListeners.forEach((fn) => fn(this.status, this.lastSyncedTime));
  }

  public getStatus(): SyncStatus {
    return this.status;
  }

  public getLastSyncedTime(): string {
    return this.lastSyncedTime;
  }

  // Debounced Autosave (1.5s delay)
  public queueAutosave(
    userId: string,
    userName: string,
    changes: {
      stories?: Story[];
      chapters?: Chapter[];
      translationMemory?: TranslationMemory[];
      vocabulary?: VocabularyItem[];
      terminology?: TerminologyItem[];
    }
  ) {
    this.setStatus('saving');

    if (changes.stories) this.pendingChanges.stories = changes.stories;
    if (changes.chapters) this.pendingChanges.chapters = changes.chapters;
    if (changes.translationMemory) this.pendingChanges.translationMemory = changes.translationMemory;
    if (changes.vocabulary) this.pendingChanges.vocabulary = changes.vocabulary;
    if (changes.terminology) this.pendingChanges.terminology = changes.terminology;

    if (this.autosaveTimer) {
      clearTimeout(this.autosaveTimer);
    }

    this.autosaveTimer = setTimeout(async () => {
      await this.pushPendingChanges(userId, userName);
    }, 1500);
  }

  public async pushPendingChanges(userId: string, userName: string): Promise<boolean> {
    if (Object.keys(this.pendingChanges).length === 0) {
      this.setStatus('synced');
      return true;
    }

    this.setStatus('syncing');
    const payload = {
      userId,
      userName,
      ...this.pendingChanges,
    };
    this.pendingChanges = {};

    try {
      // 1. If Supabase is configured, sync directly to Supabase
      if (isSupabaseConfigured()) {
        const client = getSupabaseClient();
        if (client) {
          if (payload.stories && payload.stories.length > 0) {
            for (const s of payload.stories) {
              await client.from('stories').upsert({
                id: s.id,
                owner_id: s.ownerId,
                owner_name: s.ownerName,
                title: s.title,
                author: s.author,
                description: s.description,
                cover: s.cover,
                source_language: s.sourceLanguage,
                target_language: s.targetLanguage,
                status: s.status,
                privacy: s.privacy,
                visibility: s.visibility || 'PRIVATE',
                original_visibility: s.originalVisibility || 'PRIVATE',
                translation_visibility: s.translationVisibility || 'PRIVATE',
                source_type: s.sourceType || 'USER',
                share_token: s.shareToken,
                sharing_permissions: s.sharingPermissions,
                total_chapters: s.totalChapters,
                translated_chapters: s.translatedChapters,
                updated_at: new Date().toISOString(),
              });
            }
          }
        }
      }

      // 2. Also push to local server store for instant multi-device / multi-tab sync
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`Sync server returned ${res.status}`);
      }

      const data = await res.json();
      this.lastSyncedTime = data.syncedAt || new Date().toISOString();
      localStorage.setItem('lananh_last_synced', this.lastSyncedTime);
      this.setStatus('synced');
      return true;
    } catch (err) {
      console.warn('Sync failed (offline or network error):', err);
      this.setStatus('offline');
      return false;
    }
  }

  // Pull cloud state
  public async pullCloudData(userId: string, isAdmin = false) {
    this.setStatus('syncing');
    try {
      const res = await fetch(`/api/sync/pull?userId=${encodeURIComponent(userId)}&isAdmin=${isAdmin}`);
      if (!res.ok) throw new Error('Pull failed');
      const data = await res.json();

      this.lastSyncedTime = data.lastUpdated || new Date().toISOString();
      localStorage.setItem('lananh_last_synced', this.lastSyncedTime);
      this.setStatus('synced');

      return data;
    } catch (err) {
      console.warn('Failed to pull cloud data:', err);
      this.setStatus('offline');
      return null;
    }
  }

  // Search Shared Knowledge
  public async searchSharedKnowledge(query: string, category?: string, source?: string) {
    try {
      const params = new URLSearchParams();
      if (query) params.set('q', query);
      if (category && category !== 'all') params.set('category', category);
      if (source && source !== 'all') params.set('source', source);

      const res = await fetch(`/api/knowledge/search?${params.toString()}`);
      if (!res.ok) throw new Error('Knowledge search failed');
      return await res.json();
    } catch (err) {
      console.warn('Error searching knowledge:', err);
      return { translationMemory: [], vocabulary: [], terminology: [] };
    }
  }

  // Community Contributions
  public async fetchContributions(): Promise<SharedContribution[]> {
    try {
      const res = await fetch('/api/contributions');
      if (!res.ok) throw new Error('Failed to fetch contributions');
      const data = await res.json();
      return data.contributions || [];
    } catch (err) {
      console.warn('Error fetching contributions:', err);
      return [];
    }
  }

  public async submitContribution(
    contribution: Omit<SharedContribution, 'id' | 'createdAt' | 'status'>,
    userId: string,
    userName: string
  ): Promise<SharedContribution | null> {
    try {
      const res = await fetch('/api/contributions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contribution, userId, userName }),
      });
      if (!res.ok) throw new Error('Failed to submit contribution');
      const data = await res.json();
      return data.contribution;
    } catch (err) {
      console.error('Error submitting contribution:', err);
      return null;
    }
  }

  public async reviewContribution(
    id: string,
    decision: 'APPROVED' | 'REJECTED' | 'MERGE',
    reviewerId: string,
    reviewerName: string,
    notes?: string
  ): Promise<SharedContribution | null> {
    try {
      const res = await fetch(`/api/contributions/${id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ decision, reviewerId, reviewerName, notes }),
      });
      if (!res.ok) throw new Error('Failed to review contribution');
      const data = await res.json();
      return data.contribution;
    } catch (err) {
      console.error('Error reviewing contribution:', err);
      return null;
    }
  }

  // Audit Logging
  public async logAudit(userId: string, userName: string, action: string, entityType: string, entityId: string, details: any) {
    try {
      await fetch('/api/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, userName, action, entityType, entityId, details }),
      });
    } catch (e) {
      // quiet catch
    }
  }

  public async fetchAuditLogs(): Promise<AuditLog[]> {
    try {
      const res = await fetch('/api/audit');
      if (!res.ok) return [];
      const data = await res.json();
      return data.logs || [];
    } catch (e) {
      return [];
    }
  }

  // Dashboard Stats
  public async fetchDashboardStats() {
    try {
      const res = await fetch('/api/dashboard/stats');
      if (!res.ok) return null;
      const data = await res.json();
      return data.stats;
    } catch (e) {
      return null;
    }
  }
}

export const cloudSync = new CloudSyncManager();
