import {
  Story,
  Chapter,
  TranslationSegment,
  TranslationMemory,
  PronounRule,
  Character,
  CharacterRelationship,
  StoryBible,
  PlotEvent,
  ConsistencyWarning,
  TranslationVersion,
  ArcSummary,
  GlobalTranslationMemory,
  StorySharingPermissions,
  StoryPrivacyLevel,
  StoryFileAttachment,
} from '../types';
import { generateShareToken } from './auth';

const DB_NAME = 'lananh_artistry_db';
const DB_VERSION = 2;

const DEFAULT_SHARING_PERMISSIONS: StorySharingPermissions = {
  showOriginal: false,
  showTranslation: true,
  showSummary: true,
  showCharacters: true,
  showStoryBible: false,
  showPlotTimeline: true,
  showTranslationMemory: true,
  showTerminology: true,
  showPronouns: true,
};

function normalizeStoryData(story: any): Story {
  return {
    ...story,
    ownerId: story.ownerId || 'user-lananh-01',
    ownerName: story.ownerName || 'Lan Anh',
    privacy: story.privacy || 'private',
    shareToken: story.shareToken || generateShareToken(),
    sharingPermissions: story.sharingPermissions || { ...DEFAULT_SHARING_PERMISSIONS },
  };
}

let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains('stories')) {
        db.createObjectStore('stories', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('chapters')) {
        const store = db.createObjectStore('chapters', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
        store.createIndex('chapterNumber', ['storyId', 'chapterNumber'], { unique: false });
      }
      if (!db.objectStoreNames.contains('segments')) {
        const store = db.createObjectStore('segments', { keyPath: 'segmentId' });
        store.createIndex('chapterId', 'chapterId', { unique: false });
        store.createIndex('storyId', 'storyId', { unique: false });
      }
      if (!db.objectStoreNames.contains('translation_memory')) {
        const store = db.createObjectStore('translation_memory', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
        store.createIndex('original', 'original', { unique: false });
      }
      if (!db.objectStoreNames.contains('pronoun_rules')) {
        const store = db.createObjectStore('pronoun_rules', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
      }
      if (!db.objectStoreNames.contains('characters')) {
        const store = db.createObjectStore('characters', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
      }
      if (!db.objectStoreNames.contains('relationships')) {
        const store = db.createObjectStore('relationships', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
      }
      if (!db.objectStoreNames.contains('story_bible')) {
        db.createObjectStore('story_bible', { keyPath: 'storyId' });
      }
      if (!db.objectStoreNames.contains('plot_events')) {
        const store = db.createObjectStore('plot_events', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
        store.createIndex('chapterId', 'chapterId', { unique: false });
      }
      if (!db.objectStoreNames.contains('warnings')) {
        const store = db.createObjectStore('warnings', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
        store.createIndex('chapterId', 'chapterId', { unique: false });
        store.createIndex('status', 'status', { unique: false });
      }
      if (!db.objectStoreNames.contains('versions')) {
        const store = db.createObjectStore('versions', { keyPath: 'id' });
        store.createIndex('chapterId', 'chapterId', { unique: false });
      }
      if (!db.objectStoreNames.contains('arc_summaries')) {
        const store = db.createObjectStore('arc_summaries', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
      }
      if (!db.objectStoreNames.contains('global_memory')) {
        db.createObjectStore('global_memory', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('story_files')) {
        const store = db.createObjectStore('story_files', { keyPath: 'id' });
        store.createIndex('storyId', 'storyId', { unique: false });
      }
    };

    request.onsuccess = async (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      // Seed if empty
      await seedInitialDataIfEmpty(db);
      resolve(db);
    };

    request.onerror = (event) => {
      console.error('IndexedDB open error:', event);
      reject((event.target as IDBOpenDBRequest).error);
    };
  });

  return dbPromise;
}

// Low level helpers
async function getStore(storeName: string, mode: IDBTransactionMode = 'readonly'): Promise<IDBObjectStore> {
  const db = await openDB();
  const tx = db.transaction(storeName, mode);
  return tx.objectStore(storeName);
}

// --- Stories ---
export async function getAllStories(): Promise<Story[]> {
  const store = await getStore('stories');
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => {
      const list = (req.result || []).map((s: any) => normalizeStoryData(s));
      resolve(list);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function getStoriesByUser(userId: string): Promise<Story[]> {
  const all = await getAllStories();
  return all.filter((s) => s.ownerId === userId);
}

export async function getPublicStories(): Promise<Story[]> {
  const all = await getAllStories();
  return all.filter((s) => s.privacy === 'public');
}

export async function getStoryByShareToken(token: string): Promise<Story | undefined> {
  if (!token) return undefined;
  const all = await getAllStories();
  const story = all.find((s) => s.shareToken === token);
  if (!story) return undefined;
  // If story is strictly private and not link_only or public, disallow
  if (story.privacy === 'private') return undefined;
  return story;
}

export async function regenerateStoryShareToken(storyId: string): Promise<string> {
  const story = await getStoryById(storyId);
  if (!story) throw new Error('Story not found');
  const newToken = generateShareToken();
  story.shareToken = newToken;
  await saveStory(story);
  return newToken;
}

export async function getPublicLanguageMemories(): Promise<
  Array<{
    id: string;
    original: string;
    translation: string;
    language: string;
    category?: string;
    frequency: number;
    preferred: boolean;
    storyTitle: string;
    contributorName: string;
    contextSanitized?: string;
  }>
> {
  const allStories = await getAllStories();
  // Include memories from stories that are 'public' or 'public_memory_only' OR have sharingPermissions.showTranslationMemory
  const eligibleStories = allStories.filter(
    (s) =>
      s.privacy === 'public' ||
      s.privacy === 'public_memory_only' ||
      (s.sharingPermissions && s.sharingPermissions.showTranslationMemory)
  );

  const results: any[] = [];
  for (const st of eligibleStories) {
    const memories = await getTranslationMemories(st.id);
    for (const m of memories) {
      results.push({
        id: m.id,
        original: m.original,
        translation: m.translation,
        language: m.language,
        category: m.category || 'terminology',
        frequency: m.frequency,
        preferred: m.preferred,
        storyTitle: st.title,
        contributorName: st.ownerName || 'Dịch giả',
        // Sanitize private context if story itself is private
        contextSanitized:
          st.privacy === 'private' || st.privacy === 'public_memory_only'
            ? 'Cụm từ được chia sẻ trong cộng đồng dịch thuật'
            : m.context,
      });
    }
  }

  // Also include global memories
  const globals = await getGlobalMemories();
  for (const gm of globals) {
    results.push({
      id: gm.id,
      original: gm.original,
      translation: gm.preferredTranslation,
      language: gm.language,
      category: gm.category || 'expression',
      frequency: 1,
      preferred: true,
      storyTitle: 'Quy tắc toàn hệ thống',
      contributorName: 'LanAnhArtistry Community',
      contextSanitized: gm.notes,
    });
  }

  return results;
}

export async function migrateUnassignedStoriesToUser(userId: string, userName: string): Promise<number> {
  const stories = await getAllStories();
  let count = 0;
  for (const s of stories) {
    if (!s.ownerId || s.ownerId === 'user-lananh-01' || s.ownerId === '') {
      s.ownerId = userId;
      s.ownerName = userName;
      await saveStory(s);
      count++;
    }
  }
  return count;
}

export async function getStoryById(id: string): Promise<Story | undefined> {
  const store = await getStore('stories');
  return new Promise((resolve, reject) => {
    const req = store.get(id);
    req.onsuccess = () => {
      if (req.result) {
        resolve(normalizeStoryData(req.result));
      } else {
        resolve(undefined);
      }
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveStory(story: Story): Promise<void> {
  const store = await getStore('stories', 'readwrite');
  story.updatedAt = new Date().toISOString();
  const normalized = normalizeStoryData(story);
  return new Promise((resolve, reject) => {
    const req = store.put(normalized);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteStory(id: string): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(
    ['stories', 'chapters', 'segments', 'translation_memory', 'pronoun_rules', 'characters', 'relationships', 'story_bible', 'plot_events', 'warnings', 'arc_summaries'],
    'readwrite'
  );

  tx.objectStore('stories').delete(id);
  tx.objectStore('story_bible').delete(id);

  // Clean related items
  const cleanStore = (name: string, indexName = 'storyId') => {
    const s = tx.objectStore(name);
    const idx = s.index(indexName);
    const req = idx.getAllKeys(id);
    req.onsuccess = () => {
      for (const k of req.result) {
        s.delete(k);
      }
    };
  };

  cleanStore('chapters');
  cleanStore('segments');
  cleanStore('translation_memory');
  cleanStore('pronoun_rules');
  cleanStore('characters');
  cleanStore('relationships');
  cleanStore('plot_events');
  cleanStore('warnings');
  cleanStore('arc_summaries');

  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// --- Chapters ---
export async function getChaptersByStory(storyId: string): Promise<Chapter[]> {
  const store = await getStore('chapters');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => {
      const list: Chapter[] = req.result || [];
      list.sort((a, b) => a.chapterNumber - b.chapterNumber);
      resolve(list);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function getChapterById(id: string): Promise<Chapter | undefined> {
  const store = await getStore('chapters');
  return new Promise((resolve, reject) => {
    const req = store.get(id);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveChapter(chapter: Chapter): Promise<void> {
  const store = await getStore('chapters', 'readwrite');
  chapter.updatedAt = new Date().toISOString();
  return new Promise((resolve, reject) => {
    const req = store.put(chapter);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteChapter(chapterId: string): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(['chapters', 'segments', 'warnings', 'versions', 'plot_events'], 'readwrite');
  tx.objectStore('chapters').delete(chapterId);

  const cleanByChapter = (storeName: string) => {
    const s = tx.objectStore(storeName);
    const idx = s.index('chapterId');
    const req = idx.getAllKeys(chapterId);
    req.onsuccess = () => {
      for (const k of req.result) s.delete(k);
    };
  };

  cleanByChapter('segments');
  cleanByChapter('warnings');
  cleanByChapter('versions');
  cleanByChapter('plot_events');

  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// --- Segments ---
export async function getSegmentsByChapter(chapterId: string): Promise<TranslationSegment[]> {
  const store = await getStore('segments');
  const index = store.index('chapterId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(chapterId);
    req.onsuccess = () => {
      const list: TranslationSegment[] = req.result || [];
      list.sort((a, b) => a.segmentOrder - b.segmentOrder);
      resolve(list);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveSegments(segments: TranslationSegment[]): Promise<void> {
  const store = await getStore('segments', 'readwrite');
  return new Promise((resolve, reject) => {
    const tx = store.transaction;
    for (const seg of segments) {
      store.put(seg);
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function saveSingleSegment(segment: TranslationSegment): Promise<void> {
  const store = await getStore('segments', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(segment);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Translation Memory ---
export async function getTranslationMemories(storyId: string): Promise<TranslationMemory[]> {
  const store = await getStore('translation_memory');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function saveTranslationMemory(tm: TranslationMemory): Promise<void> {
  const store = await getStore('translation_memory', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(tm);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteTranslationMemory(id: string): Promise<void> {
  const store = await getStore('translation_memory', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Pronoun Rules ---
export async function getPronounRules(storyId: string): Promise<PronounRule[]> {
  const store = await getStore('pronoun_rules');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function savePronounRule(rule: PronounRule): Promise<void> {
  const store = await getStore('pronoun_rules', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(rule);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deletePronounRule(id: string): Promise<void> {
  const store = await getStore('pronoun_rules', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Characters ---
export async function getCharacters(storyId: string): Promise<Character[]> {
  const store = await getStore('characters');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function saveCharacter(character: Character): Promise<void> {
  const store = await getStore('characters', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(character);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteCharacter(id: string): Promise<void> {
  const store = await getStore('characters', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Relationships ---
export async function getRelationships(storyId: string): Promise<CharacterRelationship[]> {
  const store = await getStore('relationships');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}
export const getCharacterRelationships = getRelationships;

export async function saveRelationship(relationship: CharacterRelationship): Promise<void> {
  const store = await getStore('relationships', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(relationship);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
export const saveCharacterRelationship = saveRelationship;

export async function deleteRelationship(id: string): Promise<void> {
  const store = await getStore('relationships', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Story Bible ---
export async function getStoryBible(storyId: string): Promise<StoryBible | undefined> {
  const store = await getStore('story_bible');
  return new Promise((resolve, reject) => {
    const req = store.get(storyId);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveStoryBible(bible: StoryBible): Promise<void> {
  const store = await getStore('story_bible', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(bible);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Plot Events ---
export async function getPlotEvents(storyId: string): Promise<PlotEvent[]> {
  const store = await getStore('plot_events');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => {
      const list: PlotEvent[] = req.result || [];
      list.sort((a, b) => a.chapterNumber - b.chapterNumber || a.order - b.order);
      resolve(list);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function savePlotEvent(event: PlotEvent): Promise<void> {
  const store = await getStore('plot_events', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(event);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deletePlotEvent(id: string): Promise<void> {
  const store = await getStore('plot_events', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Warnings ---
export async function getWarnings(storyId: string): Promise<ConsistencyWarning[]> {
  const store = await getStore('warnings');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function saveWarning(warning: ConsistencyWarning): Promise<void> {
  const store = await getStore('warnings', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(warning);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteWarning(id: string): Promise<void> {
  const store = await getStore('warnings', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Versions ---
export async function getVersions(chapterId: string): Promise<TranslationVersion[]> {
  const store = await getStore('versions');
  const index = store.index('chapterId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(chapterId);
    req.onsuccess = () => {
      const list: TranslationVersion[] = req.result || [];
      list.sort((a, b) => b.versionNumber - a.versionNumber);
      resolve(list);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveVersion(version: TranslationVersion): Promise<void> {
  const store = await getStore('versions', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(version);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Arc Summaries ---
export async function getArcSummaries(storyId: string): Promise<ArcSummary[]> {
  const store = await getStore('arc_summaries');
  const index = store.index('storyId');
  return new Promise((resolve, reject) => {
    const req = index.getAll(storyId);
    req.onsuccess = () => {
      const list: ArcSummary[] = req.result || [];
      list.sort((a, b) => a.startChapter - b.startChapter);
      resolve(list);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveArcSummary(arc: ArcSummary): Promise<void> {
  const store = await getStore('arc_summaries', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(arc);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Global Memory ---
export async function getGlobalMemories(): Promise<GlobalTranslationMemory[]> {
  const store = await getStore('global_memory');
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function saveGlobalMemory(item: GlobalTranslationMemory): Promise<void> {
  const store = await getStore('global_memory', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(item);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Export & Import ---
export async function exportStoryData(storyId: string) {
  const story = await getStoryById(storyId);
  if (!story) throw new Error('Truyện không tồn tại');

  const chapters = await getChaptersByStory(storyId);
  const bible = await getStoryBible(storyId);
  const characters = await getCharacters(storyId);
  const relationships = await getRelationships(storyId);
  const pronounRules = await getPronounRules(storyId);
  const translationMemories = await getTranslationMemories(storyId);
  const plotEvents = await getPlotEvents(storyId);
  const warnings = await getWarnings(storyId);
  const arcSummaries = await getArcSummaries(storyId);

  // Collect segments & versions
  const allSegments: TranslationSegment[] = [];
  const allVersions: TranslationVersion[] = [];
  for (const ch of chapters) {
    const segs = await getSegmentsByChapter(ch.id);
    allSegments.push(...segs);
    const vers = await getVersions(ch.id);
    allVersions.push(...vers);
  }

  return {
    version: '1.0',
    exportedAt: new Date().toISOString(),
    story,
    chapters,
    segments: allSegments,
    bible,
    characters,
    relationships,
    pronounRules,
    translationMemories,
    plotEvents,
    warnings,
    versions: allVersions,
    arcSummaries,
  };
}

export async function exportAllData() {
  const stories = await getAllStories();
  const storyDataList = [];
  for (const s of stories) {
    storyDataList.push(await exportStoryData(s.id));
  }
  const globalMemories = await getGlobalMemories();

  return {
    version: '1.0',
    type: 'LanAnhArtistry_FULL_BACKUP',
    exportedAt: new Date().toISOString(),
    stories: storyDataList,
    globalMemories,
  };
}

export async function importData(jsonData: any): Promise<{ storiesCount: number }> {
  if (!jsonData) throw new Error('Dữ liệu trống hoặc không hợp lệ');

  if (jsonData.type === 'LanAnhArtistry_FULL_BACKUP' && Array.isArray(jsonData.stories)) {
    for (const item of jsonData.stories) {
      await importSingleStoryPackage(item);
    }
    if (Array.isArray(jsonData.globalMemories)) {
      for (const gm of jsonData.globalMemories) {
        await saveGlobalMemory(gm);
      }
    }
    return { storiesCount: jsonData.stories.length };
  } else if (jsonData.story) {
    await importSingleStoryPackage(jsonData);
    return { storiesCount: 1 };
  } else {
    throw new Error('Định dạng tệp sao lưu LanAnhArtistry không hợp lệ');
  }
}

async function importSingleStoryPackage(pkg: any) {
  if (!pkg.story || !pkg.story.id) return;
  await saveStory(pkg.story);
  if (pkg.bible) await saveStoryBible(pkg.bible);

  if (Array.isArray(pkg.chapters)) {
    for (const c of pkg.chapters) await saveChapter(c);
  }
  if (Array.isArray(pkg.segments)) {
    await saveSegments(pkg.segments);
  }
  if (Array.isArray(pkg.characters)) {
    for (const char of pkg.characters) await saveCharacter(char);
  }
  if (Array.isArray(pkg.relationships)) {
    for (const rel of pkg.relationships) await saveRelationship(rel);
  }
  if (Array.isArray(pkg.pronounRules)) {
    for (const pr of pkg.pronounRules) await savePronounRule(pr);
  }
  if (Array.isArray(pkg.translationMemories)) {
    for (const tm of pkg.translationMemories) await saveTranslationMemory(tm);
  }
  if (Array.isArray(pkg.plotEvents)) {
    for (const pe of pkg.plotEvents) await savePlotEvent(pe);
  }
  if (Array.isArray(pkg.warnings)) {
    for (const w of pkg.warnings) await saveWarning(w);
  }
  if (Array.isArray(pkg.versions)) {
    for (const v of pkg.versions) await saveVersion(v);
  }
  if (Array.isArray(pkg.arcSummaries)) {
    for (const a of pkg.arcSummaries) await saveArcSummary(a);
  }
}

// Initial Data Seeding
async function seedInitialDataIfEmpty(db: IDBDatabase) {
  const tx = db.transaction('stories', 'readonly');
  const countReq = tx.objectStore('stories').count();

  return new Promise<void>((resolve) => {
    countReq.onsuccess = async () => {
      if (countReq.result === 0) {
        console.log('Seeding initial LanAnhArtistry demo data...');
        await seedDefaultStories();
      }
      resolve();
    };
    countReq.onerror = () => resolve();
  });
}

async function seedDefaultStories() {
  const storyAId = 'story-vantien-01';
  const chapter35Id = 'chap-35-vantien';
  const chapter36Id = 'chap-36-vantien';

  const storyA: Story = {
    id: storyAId,
    ownerId: 'user-lananh-01',
    ownerName: 'Lan Anh',
    title: 'Vấn Tiên (问仙)',
    author: 'Tiêu Diêu Khách',
    sourceLanguage: 'zh',
    targetLanguage: 'vi',
    description: 'Thiếu niên Lâm Phong bước vào tu tiên lộ, phát hiện bí mật chấn động về sư môn và huyết mạch nghìn năm. Bản dịch trau chuốt, chú trọng văn phong cổ phong võ hiệp & tiên hiệp.',
    status: 'translating',
    privacy: 'private',
    shareToken: 'sh_vantien_private_key_01',
    sharingPermissions: {
      showOriginal: false,
      showTranslation: true,
      showSummary: true,
      showCharacters: true,
      showStoryBible: false,
      showPlotTimeline: true,
      showTranslationMemory: true,
      showTerminology: true,
      showPronouns: true,
    },
    totalChapters: 120,
    translatedChapters: 35,
    createdAt: '2026-08-10T10:00:00.000Z',
    updatedAt: new Date().toISOString(),
    lastOpenedAt: new Date().toISOString(),
  };

  const storyB: Story = {
    id: 'story-clockwork-02',
    ownerId: 'user-lananh-01',
    ownerName: 'Lan Anh',
    title: 'The Clockwork Heart',
    author: 'Arthur Pendelton',
    sourceLanguage: 'en',
    targetLanguage: 'vi',
    description: 'Thành phố hơi nước New London thế kỷ 19, một thợ chế tác đồng hồ vô tình khám phá ra quả tim cơ khí vĩnh cửu có khả năng điều khiển thời gian.',
    status: 'translating',
    privacy: 'link_only',
    shareToken: 'sh_clockwork_heart_demo_77',
    sharingPermissions: {
      showOriginal: true,
      showTranslation: true,
      showSummary: true,
      showCharacters: true,
      showStoryBible: true,
      showPlotTimeline: true,
      showTranslationMemory: true,
      showTerminology: true,
      showPronouns: true,
    },
    totalChapters: 45,
    translatedChapters: 12,
    createdAt: '2026-09-01T08:00:00.000Z',
    updatedAt: '2026-10-02T14:20:00.000Z',
    lastOpenedAt: '2026-10-02T14:20:00.000Z',
  };

  // Community Public Story to demonstrate public discovery & shared language memory
  const storyC: Story = {
    id: 'story-bachya-03',
    ownerId: 'user-minhvu-02',
    ownerName: 'Minh Vũ',
    title: 'Bạch Dạ Hàn Sương (白夜寒霜)',
    author: 'Tuyết Sơn Ẩn Giả',
    sourceLanguage: 'zh',
    targetLanguage: 'vi',
    description: 'Bạch Dạ Kiếm Tôn truy tìm cổ kiếm thất lạc giữa Bắc Vực băng nguyên, kết bạn cùng dược sư Diệp Thanh.',
    status: 'translating',
    privacy: 'public',
    shareToken: 'sh_bach_ya_han_suong_pub',
    sharingPermissions: {
      showOriginal: false,
      showTranslation: true,
      showSummary: true,
      showCharacters: true,
      showStoryBible: false,
      showPlotTimeline: true,
      showTranslationMemory: true,
      showTerminology: true,
      showPronouns: true,
    },
    totalChapters: 80,
    translatedChapters: 22,
    createdAt: '2026-09-15T08:00:00.000Z',
    updatedAt: '2026-10-04T12:00:00.000Z',
    lastOpenedAt: '2026-10-04T12:00:00.000Z',
  };

  await saveStory(storyA);
  await saveStory(storyB);
  await saveStory(storyC);

  // Characters for Story A
  const charLamPhong: Character = {
    id: 'char-lam-phong',
    storyId: storyAId,
    name: 'Lâm Phong',
    aliases: ['Phong ca', 'Lâm sư đệ', 'Tiểu Phong'],
    gender: 'male',
    role: 'protagonist',
    status: 'alive',
    identity: 'Đệ tử ngoại môn Thanh Vân Tông, mang kiếm cốt thiên bẩm',
    faction: 'Thanh Vân Kiếm Tông',
    personality: 'Kiên nghị, trầm ổn, trọng ân nghĩa nhưng quyết đoán khi gặp hiểm nguy',
    speakingStyle: 'Khiêm nhường với tiền bối, cương trực trước đối thủ',
    firstAppearance: 1,
    importantChapters: [1, 5, 12, 18, 30, 35, 36],
    notes: 'Đang nắm giữ bí mật về Huyết Sắc Cổ Ngọc tìm thấy ở U Hồn Cốc.',
  };

  const charNguyenAn: Character = {
    id: 'char-nguyen-an',
    storyId: storyAId,
    name: 'Nguyễn An',
    aliases: ['An sư huynh', 'Nguyễn sư huynh', 'Đại sư huynh thất phong'],
    gender: 'male',
    role: 'supporting',
    status: 'alive',
    identity: 'Đại đệ tử của Vấn Tiên Đỉnh, người hướng dẫn Lâm Phong nhập môn',
    faction: 'Thanh Vân Kiếm Tông',
    personality: 'Ôn hòa ngoài mặt nhưng mang tâm sự nặng nề về gia tộc',
    speakingStyle: 'Nhã nhặn, quan tâm, thường xưng huynh gọi đệ',
    firstAppearance: 2,
    importantChapters: [2, 5, 10, 15, 28, 35, 36],
    notes: 'Ở Chapter 36 bắt đầu xảy ra rạn nứt quan hệ vì Lâm Phong tra hỏi sự thật về cái chết của gia tộc.',
  };

  const charTieuDaoTu: Character = {
    id: 'char-tieu-dao-tu',
    storyId: storyAId,
    name: 'Tiêu Dao Tử',
    aliases: ['Sư tôn', 'Vấn Tiên Đỉnh Chủ', 'Chưởng môn sư bá'],
    gender: 'male',
    role: 'supporting',
    status: 'alive',
    identity: 'Đỉnh chủ Vấn Tiên Đỉnh, sư phụ của Nguyễn An và Lâm Phong',
    faction: 'Thanh Vân Kiếm Tông',
    personality: 'Thâm sâu khó lường, nghiêm khắc nhưng che chở đệ tử',
    speakingStyle: 'Trầm ấm, uy nghiêm, thường dùng từ ngữ huyền cơ',
    firstAppearance: 2,
    importantChapters: [2, 8, 14, 25, 36],
    notes: 'Quy tắc xưng hô: Lâm Phong luôn gọi là "Sư tôn" (⭐ preferred). Tuyệt đối không dịch thành "Sư phụ".',
  };

  const charTranMinh: Character = {
    id: 'char-tran-minh',
    storyId: storyAId,
    name: 'Trần Minh',
    aliases: ['Trần sư huynh', 'Minh thiếu gia'],
    gender: 'male',
    role: 'antagonist',
    status: 'alive',
    identity: 'Trưởng tử Trần gia, đệ tử Chấp Pháp Đường',
    faction: 'Chấp Pháp Đường - Thanh Vân Tông',
    personality: 'Kiêu ngạo, hẹp hòi, ghen ghét thiên phú của Lâm Phong',
    speakingStyle: 'Châm chọc, hống hách',
    firstAppearance: 15,
    importantChapters: [15, 22, 31, 36],
    notes: 'Đang âm mưu vu oan Lâm Phong câu kết ma đạo.',
  };

  await saveCharacter(charLamPhong);
  await saveCharacter(charNguyenAn);
  await saveCharacter(charTieuDaoTu);
  await saveCharacter(charTranMinh);

  // Relationships
  const rel1: CharacterRelationship = {
    id: 'rel-1',
    storyId: storyAId,
    characterA: 'Lâm Phong',
    characterB: 'Nguyễn An',
    relationshipType: 'Sư đệ / Sư huynh',
    currentStatus: 'Xung đột âm thầm (Chapter 36)',
    startChapter: 2,
    context: 'Từng là đồng môn gắn bó keo sơn, nay nảy sinh nghi kỵ vì bí mật gia tộc.',
    notes: 'Cách xưng hô có nguy cơ biến đổi từ huynh-đệ sang ta-ngươi.',
  };

  const rel2: CharacterRelationship = {
    id: 'rel-2',
    storyId: storyAId,
    characterA: 'Lâm Phong',
    characterB: 'Tiêu Dao Tử',
    relationshipType: 'Đệ tử / Sư tôn',
    currentStatus: 'Tôn kính nhưng giữ khoảng cách',
    startChapter: 2,
    context: 'Lâm Phong bái Tiêu Dao Tử làm thầy tại Vấn Tiên Đỉnh.',
    notes: 'Luôn giữ xưng hô chuẩn mực: đệ tử / sư tôn.',
  };

  await saveRelationship(rel1);
  await saveRelationship(rel2);

  // Pronoun Rules
  const pr1: PronounRule = {
    id: 'pr-1',
    storyId: storyAId,
    fromCharacter: 'Lâm Phong',
    toCharacter: 'Nguyễn An',
    selfPronoun: 'đệ',
    targetAddress: 'huynh',
    context: 'Giao tiếp hàng ngày giữa hai sư huynh đệ đồng môn',
    startChapter: 2,
    endChapter: 35,
    status: 'active',
    chapters: [2, 5, 8, 12, 18, 25, 30, 35],
  };

  const pr2: PronounRule = {
    id: 'pr-2',
    storyId: storyAId,
    fromCharacter: 'Nguyễn An',
    toCharacter: 'Lâm Phong',
    selfPronoun: 'huynh',
    targetAddress: 'đệ',
    context: 'Quan hệ thân thiết, Nguyễn An chỉ dạy Lâm Phong',
    startChapter: 2,
    endChapter: 35,
    status: 'active',
    chapters: [2, 5, 8, 12, 18, 25, 30, 35],
  };

  const pr3: PronounRule = {
    id: 'pr-3',
    storyId: storyAId,
    fromCharacter: 'Lâm Phong',
    toCharacter: 'Tiêu Dao Tử',
    selfPronoun: 'đệ tử',
    targetAddress: 'sư tôn',
    context: 'Bái kiến và thỉnh giáo sư phụ',
    startChapter: 2,
    status: 'active',
    chapters: [2, 5, 8, 11, 20, 28],
  };

  await savePronounRule(pr1);
  await savePronounRule(pr2);
  await savePronounRule(pr3);

  // Translation Memories
  const tm1: TranslationMemory = {
    id: 'tm-su-ton',
    storyId: storyAId,
    original: '师尊',
    translation: 'sư tôn',
    language: 'zh',
    context: 'Lâm Phong và môn hạ gọi Tiêu Dao Tử',
    characterFrom: 'Lâm Phong',
    characterTo: 'Tiêu Dao Tử',
    relationship: 'Đệ tử → Sư tôn',
    chapterIds: [2, 5, 8, 11, 20, 28],
    frequency: 18,
    firstChapter: 2,
    lastChapter: 28,
    status: 'active',
    preferred: true,
    notes: 'Quy tắc nghiêm ngặt: Trong tông môn dùng "sư tôn", không dùng "sư phụ".',
    category: 'title',
  };

  const tm2: TranslationMemory = {
    id: 'tm-su-huynh',
    storyId: storyAId,
    original: '师兄',
    translation: 'sư huynh',
    language: 'zh',
    context: 'Gọi đệ tử nhập môn trước',
    characterFrom: 'Lâm Phong',
    characterTo: 'Nguyễn An',
    relationship: 'Sư đệ → Sư huynh',
    chapterIds: [2, 4, 7, 10, 15, 22, 28, 35],
    frequency: 24,
    firstChapter: 2,
    lastChapter: 35,
    status: 'active',
    preferred: true,
    notes: 'Có thể dịch là "huynh trưởng" khi bối cảnh gia tộc.',
    category: 'title',
  };

  const tm3: TranslationMemory = {
    id: 'tm-cuoi-lanh',
    storyId: storyAId,
    original: '冷笑',
    translation: 'cười lạnh',
    language: 'zh',
    context: 'Mô tả thái độ khinh miệt của đối thủ trong giao chiến hoặc chất vấn',
    chapterIds: [4, 9, 15, 22, 31],
    frequency: 12,
    firstChapter: 4,
    lastChapter: 31,
    status: 'active',
    preferred: true,
    notes: 'Ưu tiên giữ cụm "cười lạnh" thay vì "cười khẩy" để hợp phong cách tiên hiệp.',
    category: 'expression',
  };

  const tm4: TranslationMemory = {
    id: 'tm-tong-mon',
    storyId: storyAId,
    original: '宗门',
    translation: 'tông môn',
    language: 'zh',
    context: 'Chỉ Thanh Vân Kiếm Tông nói chung',
    chapterIds: [1, 3, 7, 12, 19, 26, 34],
    frequency: 19,
    firstChapter: 1,
    lastChapter: 34,
    status: 'active',
    preferred: true,
    notes: 'Thống nhất dùng "tông môn", hạn chế dùng "môn phái" trừ khi nói về các thế lực ngoại lai.',
    category: 'terminology',
  };

  await saveTranslationMemory(tm1);
  await saveTranslationMemory(tm2);
  await saveTranslationMemory(tm3);
  await saveTranslationMemory(tm4);

  // Story Bible for Story A
  const bibleA: StoryBible = {
    id: 'bible-vantien',
    storyId: storyAId,
    locations: [
      { id: 'loc-1', name: 'Thanh Vân Tông', description: 'Đệ nhất kiếm tông tại Trung Vực, tọa lạc trên chín ngọn linh sơn quanh năm mây mù bao phủ.', firstChapter: 1 },
      { id: 'loc-2', name: 'Vấn Tiên Đỉnh', description: 'Đỉnh núi cao nhất Thanh Vân Tông, nơi Tiêu Dao Tử tu luyện và đặt Vấn Tiên Thạch.', firstChapter: 2 },
      { id: 'loc-3', name: 'U Hồn Cốc', description: 'Cấm địa phía sau tông môn, nơi từng phong ấn huyết linh ma thú ngàn năm trước.', firstChapter: 18 },
    ],
    organizations: [
      { id: 'org-1', name: 'Thanh Vân Kiếm Tông', description: 'Chính đạo danh môn, gồm chín ngọn linh phong chuyên về kiếm đạo.', leader: 'Tiêu Dao Tử' },
      { id: 'org-2', name: 'Chấp Pháp Đường', description: 'Cơ quan giám sát đệ tử và thực thi tông quy, phong cách tàn nhẫn cứng nhắc.', leader: 'Trần Trưởng Lão' },
    ],
    terminology: [
      { id: 'term-1', term: 'Trúc Cơ', translation: 'Trúc Cơ', definition: 'Cảnh giới thứ hai sau Luyện Khí, đắp nền đạo cơ', category: 'Tu vi' },
      { id: 'term-2', term: 'Kim Đan', translation: 'Kim Đan', definition: 'Cảnh giới ngưng tụ kim đan bất diệt', category: 'Tu vi' },
      { id: 'term-3', term: 'Kiếm Ý', translation: 'kiếm ý', definition: 'Cảnh giới lĩnh ngộ bản nguyên của kiếm, chia làm sơ thành, đại thành, viên mãn', category: 'Chiến kỹ' },
    ],
    importantObjects: [
      { id: 'obj-1', name: 'Huyết Sắc Cổ Ngọc', originalName: '血色古玉', owner: 'Lâm Phong', description: 'Bảo vật di vật mẹ Lâm Phong để lại, có khả năng kích hoạt bí cảnh U Hồn Cốc.' },
    ],
    mysteries: [
      { id: 'mys-1', title: 'Thân thế thực sự của Lâm Phong', description: 'Cha mẹ Lâm Phong bị hãm hại 15 năm trước tại Tiên Lạc Thành; người đứng sau dường như là trưởng lão trong môn phái.', status: 'partially_revealed', clues: ['Ngọc bội huyết sắc', 'Lời căn dặn của Tiêu Dao Tử ở Ch. 14'] },
      { id: 'mys-2', title: 'Động cơ thật của Nguyễn An', description: 'Nguyễn An tiếp cận Lâm Phong là do lòng tốt chân thật hay có mệnh lệnh bí mật từ gia tộc?', status: 'unresolved', clues: ['Bức thư mật giấu trong động phủ Ch. 35'] },
    ],
    importantQuotes: [
      { id: 'quote-1', original: '剑本凡铁，因心而动。', translation: 'Kiếm vốn là sắt vụn, chỉ vì tâm người mà chuyển động.', speaker: 'Tiêu Dao Tử', chapter: 2, context: 'Lời dạy lúc Lâm Phong bắt đầu học kiếm' },
    ],
    worldbuildingRules: [
      { id: 'rule-1', title: 'Quy tắc giai tầng tu chân', description: 'Phàm nhân < Luyện Khí < Trúc Cơ < Kim Đan < Nguyên Anh < Hóa Thần', category: 'Tu vi' },
      { id: 'rule-2', title: 'Đẳng cấp phi kiếm', description: 'Phàm kiếm < Linh kiếm < Pháp bảo < Cổ bảo < Tiên khí', category: 'Bảo vật' },
    ],
    translationStyle: {
      tone: 'Cổ phong, trầm hùng, hàm súc',
      narrativeStyle: 'Văn phong văn học, mạch lạc, dùng từ Hán Việt chính xác',
      dialogueStyle: 'Khí chất tu tiên, đối thoại tự nhiên, chuẩn lễ nghi bối phận',
      formality: 'Trang trọng khi nói với tiền bối; tình cảm huynh đệ giữa đồng môn',
      preferredVocabulary: ['sư tôn', 'sư huynh', 'tông môn', 'linh khí', 'kiếm ý', 'động phủ'],
      preferredPronouns: ['đệ / huynh', 'đệ tử / sư tôn', 'ta / ngươi'],
      forbiddenTerms: ['sư phụ (dùng sư tôn)', 'bạn bè (dùng đồng môn)', 'cậu/tớ'],
      specialRules: ['Khi hai nhân vật cãi nhau gay gắt, có thể chuyển từ xưng hô huynh-đệ sang ta-ngươi nhưng cần ghi chú vào Character Timeline.'],
    },
  };

  await saveStoryBible(bibleA);

  // Plot Events
  const pe1: PlotEvent = {
    id: 'pe-1',
    storyId: storyAId,
    chapterId: 'chap-1-demo',
    chapterNumber: 1,
    title: 'Lâm Phong nhập môn Thanh Vân Kiếm Tông',
    description: 'Vượt qua khảo nghiệm Linh Kiếm Thạch, được nhận làm đệ tử ngoại môn.',
    characters: ['Lâm Phong'],
    importance: 'major',
    order: 1,
  };

  const pe2: PlotEvent = {
    id: 'pe-2',
    storyId: storyAId,
    chapterId: 'chap-2-demo',
    chapterNumber: 2,
    title: 'Gặp gỡ Nguyễn An và bái kiến Tiêu Dao Tử',
    description: 'Nguyễn An dẫn Lâm Phong lên Vấn Tiên Đỉnh, Tiêu Dao Tử truyền lại khẩu quyết Kiếm Tâm.',
    characters: ['Lâm Phong', 'Nguyễn An', 'Tiêu Dao Tử'],
    importance: 'major',
    order: 2,
  };

  const pe3: PlotEvent = {
    id: 'pe-3',
    storyId: storyAId,
    chapterId: 'chap-18-demo',
    chapterNumber: 18,
    title: 'Biến cố U Hồn Cốc',
    description: 'Huyết Sắc Cổ Ngọc phát sáng, Lâm Phong cứu Nguyễn An thoát khỏi ma vật.',
    characters: ['Lâm Phong', 'Nguyễn An'],
    importance: 'climax',
    order: 3,
  };

  const pe4: PlotEvent = {
    id: 'pe-4',
    storyId: storyAId,
    chapterId: chapter35Id,
    chapterNumber: 35,
    title: 'Bí mật bức mật thư hé lộ',
    description: 'Lâm Phong phát hiện vết tích cho thấy cái chết của song thân có liên quan đến gia tộc của Nguyễn An.',
    characters: ['Lâm Phong', 'Nguyễn An'],
    importance: 'turning_point',
    order: 4,
  };

  await savePlotEvent(pe1);
  await savePlotEvent(pe2);
  await savePlotEvent(pe3);
  await savePlotEvent(pe4);

  // Chapter 35 (Reviewed / Completed)
  const chap35: Chapter = {
    id: chapter35Id,
    storyId: storyAId,
    chapterNumber: 35,
    title: 'Bão tố trước bình minh',
    originalText: `夜色如墨，问仙峰上一片死寂。
林枫独自坐在洞府中，掌心握着那枚血色古玉。
门外传来熟悉的脚步声，阮安推门而入，神色复杂。
“林师弟，你为何还不休息？”阮安低声问道。
林枫抬头看着他，眼神中多了一丝从未有过的疏离。`,
    translationText: `Màn đêm đặc quánh như mực, trên Vấn Tiên Đỉnh hoàn toàn tĩnh mịch.
Lâm Phong một mình ngồi trong động phủ, lòng bàn tay siết chặt khối Huyết Sắc Cổ Ngọc.
Bên ngoài vang lên tiếng bước chân quen thuộc, Nguyễn An đẩy cửa bước vào, thần sắc phức tạp.
"Lâm sư đệ, sao đệ vẫn chưa nghỉ ngơi?" Nguyễn An trầm giọng hỏi.
Lâm Phong ngẩng đầu nhìn y, trong ánh mắt thêm một phần xa cách chưa từng có.`,
    status: 'completed',
    summary: 'Lâm Phong nắm giữ manh mối về thảm án gia tộc, Nguyễn An đến thăm giữa đêm nhưng nhận thấy sự đề phòng và xa cách rõ rệt từ sư đệ.',
    createdAt: '2026-10-01T15:00:00.000Z',
    updatedAt: '2026-10-01T18:00:00.000Z',
  };
  await saveChapter(chap35);

  // Chapter 36 (Current active chapter in progress)
  const chap36Original = `阮安见林枫沉默不语，心头微微一沉，缓步走到案前。
“师弟，难道你还在怀疑当年的事与我阮家有关？”
林枫冷笑一声，终于站起身来。
“师兄，你当真不知道当年那封密信的下落吗？”
两人的目光在昏暗的烛火中碰撞，气氛顿时剑拔弩张。
窗外风声萧瑟，仿佛一场席卷整个宗门的大劫即将降临。
“若你执意如此，休怪我不再留情面。”阮安的声音彻底冷了下来。`;

  const chap36Translation = `Nguyễn An thấy Lâm Phong im lặng không nói, trong lòng hơi chùng xuống, chậm rãi bước đến trước án thư.
"Sư đệ, lẽ nào đệ vẫn còn nghi ngờ chuyện năm xưa có liên quan tới Nguyễn gia của ta?"
Lâm Phong cười lạnh một tiếng, cuối cùng cũng đứng dậy.
"Sư huynh, huynh thật sự không biết tung tích của bức mật thư năm xưa sao?"
Ánh mắt hai người va chạm nhau dưới ánh nến chập chờn, bầu không khí lập tức trở nên căng như dây đàn.
Gió rít ngoài cửa sổ, tựa như một đại kiếp sắp sửa cuốn qua toàn bộ môn phái.
"Nếu đệ đã khăng khăng như thế, đừng trách ta không nể tình." Giọng của Nguyễn An đã hoàn toàn lạnh ngắt.`;

  const chap36: Chapter = {
    id: chapter36Id,
    storyId: storyAId,
    chapterNumber: 36,
    title: 'Đoạn Tuyệt',
    originalText: chap36Original,
    translationText: chap36Translation,
    status: 'translating',
    summary: 'Nguyễn An chất vấn Lâm Phong về mối nghi ngờ giữa hai người. Lâm Phong gặng hỏi về bức mật thư. Căng thẳng leo thang đỉnh điểm khi Nguyễn An đổi thái độ cứng rắn.',
    createdAt: '2026-10-04T09:00:00.000Z',
    updatedAt: new Date().toISOString(),
  };
  await saveChapter(chap36);

  // Segments for Chapter 36
  const segsChap36: TranslationSegment[] = [
    {
      segmentId: 'seg-36-01',
      chapterId: chapter36Id,
      storyId: storyAId,
      segmentOrder: 1,
      originalText: '阮安见林枫沉默不语，心头微微一沉，缓步走到案前。',
      translatedText: 'Nguyễn An thấy Lâm Phong im lặng không nói, trong lòng hơi chùng xuống, chậm rãi bước đến trước án thư.',
      translationStatus: 'translated',
      notes: '',
    },
    {
      segmentId: 'seg-36-02',
      chapterId: chapter36Id,
      storyId: storyAId,
      segmentOrder: 2,
      originalText: '“师弟，难道你还在怀疑当年的事与我阮家有关？”',
      translatedText: '“Sư đệ, lẽ nào đệ vẫn còn nghi ngờ chuyện năm xưa có liên quan tới Nguyễn gia của ta?”',
      translationStatus: 'translated',
      characterFrom: 'Nguyễn An',
      characterTo: 'Lâm Phong',
      notes: 'Nguyễn An vẫn đang xưng hô đệ/ta',
    },
    {
      segmentId: 'seg-36-03',
      chapterId: chapter36Id,
      storyId: storyAId,
      segmentOrder: 3,
      originalText: '林枫冷笑一声，终于站起身来。',
      translatedText: 'Lâm Phong cười lạnh một tiếng, cuối cùng cũng đứng dậy.',
      translationStatus: 'translated',
      notes: 'Khớp TM "冷笑 → cười lạnh"',
    },
    {
      segmentId: 'seg-36-04',
      chapterId: chapter36Id,
      storyId: storyAId,
      segmentOrder: 4,
      originalText: '“师兄，你当真不知道当年那封密信的下落吗？”',
      translatedText: '“Sư huynh, huynh thật sự không biết tung tích của bức mật thư năm xưa sao?”',
      translationStatus: 'translated',
      characterFrom: 'Lâm Phong',
      characterTo: 'Nguyễn An',
      notes: 'Lâm Phong hỏi dồn dập',
    },
    {
      segmentId: 'seg-36-05',
      chapterId: chapter36Id,
      storyId: storyAId,
      segmentOrder: 5,
      originalText: '两人的目光在昏暗的烛火中碰撞，气氛顿时剑拔弩张。',
      translatedText: 'Ánh mắt hai người va chạm nhau dưới ánh nến chập chờn, bầu không khí lập tức trở nên căng như dây đàn.',
      translationStatus: 'translated',
      notes: '',
    },
    {
      segmentId: 'seg-36-06',
      chapterId: chapter36Id,
      storyId: storyAId,
      segmentOrder: 6,
      originalText: '窗外风声萧瑟，仿佛一场席卷整个宗门的大劫即将降临。',
      translatedText: 'Gió rít ngoài cửa sổ, tựa như một đại kiếp sắp sửa cuốn qua toàn bộ môn phái.',
      translationStatus: 'translated',
      notes: 'Cảnh báo: Dùng "môn phái" thay vì quy chuẩn "tông môn" của Story Bible',
    },
    {
      segmentId: 'seg-36-07',
      chapterId: chapter36Id,
      storyId: storyAId,
      segmentOrder: 7,
      originalText: '“若你执意如此，休怪我不再留情面。”阮安的声音彻底冷了下来。',
      translatedText: '“Nếu đệ đã khăng khăng như thế, đừng trách ta không nể tình.” Giọng của Nguyễn An đã hoàn toàn lạnh ngắt.',
      translationStatus: 'translated',
      characterFrom: 'Nguyễn An',
      characterTo: 'Lâm Phong',
      notes: 'Chuyển biến tâm lý quan trọng',
    },
  ];
  await saveSegments(segsChap36);

  // Version 1 of Chapter 36
  const ver1: TranslationVersion = {
    id: 'ver-36-1',
    chapterId: chapter36Id,
    versionNumber: 1,
    translationText: chap36Translation,
    summary: 'Bản dịch khởi tạo lần đầu cho Chapter 36',
    savedAt: '2026-10-04T10:15:00.000Z',
    author: 'Lan Anh',
  };
  await saveVersion(ver1);

  // Consistency Warnings for Chapter 36 to demonstrate Review Center
  const warn1: ConsistencyWarning = {
    id: 'warn-1',
    storyId: storyAId,
    chapterId: chapter36Id,
    chapterNumber: 36,
    segmentId: 'seg-36-06',
    type: 'terminology',
    severity: 'medium',
    original: '宗门',
    previousTranslation: 'tông môn',
    currentTranslation: 'môn phái',
    relatedChapters: [1, 3, 7, 12, 19, 26, 34],
    status: 'open',
    explanation: 'Từ "宗门" trước đây ở 7 chapter (Ch. 1, 3, 7, 12, 19, 26, 34) luôn được dịch nhất quán là "tông môn" (⭐ Preferred). Ở đoạn 6 chapter 36 đang dùng "môn phái".',
    createdAt: new Date().toISOString(),
  };

  const warn2: ConsistencyWarning = {
    id: 'warn-2',
    storyId: storyAId,
    chapterId: chapter36Id,
    chapterNumber: 36,
    segmentId: 'seg-36-07',
    type: 'pronoun',
    severity: 'high',
    original: '休怪我不再留情面',
    previousTranslation: 'huynh / đệ',
    currentTranslation: 'ta / đệ',
    relatedCharacters: ['Nguyễn An', 'Lâm Phong'],
    relatedChapters: [2, 5, 8, 12, 18, 25, 30, 35],
    status: 'open',
    explanation: 'Nguyễn An xưng "ta" thay vì "huynh" như suốt 8 chapter trước đó. Đây có thể là thay đổi chủ ý do rạn nứt quan hệ (Intentional Change) hoặc sơ suất xưng hô.',
    createdAt: new Date().toISOString(),
  };

  await saveWarning(warn1);
  await saveWarning(warn2);

  // Arc Summary
  const arc1: ArcSummary = {
    id: 'arc-1',
    storyId: storyAId,
    arcTitle: 'Quyển 1: Kiếm Khởi Thanh Vân',
    startChapter: 1,
    endChapter: 35,
    summary: 'Lâm Phong bái nhập Thanh Vân Kiếm Tông, kết thân với sư huynh Nguyễn An, vượt qua khảo hạch ngoại môn và sống sót qua thảm họa U Hồn Cốc, dần khám phá ra bí mật về Huyết Sắc Cổ Ngọc.',
  };
  await saveArcSummary(arc1);

  // Global Memory
  const gm1: GlobalTranslationMemory = {
    id: 'gm-1',
    original: '冷笑',
    preferredTranslation: 'cười lạnh',
    language: 'zh',
    category: 'expression',
    notes: 'Quy tắc toàn hệ thống cho tiểu thuyết kiếm hiệp / tiên hiệp',
  };
  const gm2: GlobalTranslationMemory = {
    id: 'gm-2',
    original: '深吸了一口气',
    preferredTranslation: 'hít sâu một hơi',
    language: 'zh',
    category: 'expression',
    notes: 'Thói quen dịch hành động nhân vật',
  };
  await saveGlobalMemory(gm1);
  await saveGlobalMemory(gm2);
}

// ==========================================
// DATA MIGRATION & BACKUP / EXPORT HELPERS
// ==========================================

export async function detectLocalDataSummary(): Promise<{
  storiesCount: number;
  chaptersCount: number;
  segmentsCount: number;
  charactersCount: number;
  tmCount: number;
  pronounRulesCount: number;
  totalSizeEstimatedKb: number;
}> {
  try {
    const db = await openDB();
    const countStore = (name: string): Promise<number> => {
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(name, 'readonly');
          const store = tx.objectStore(name);
          const req = store.count();
          req.onsuccess = () => resolve(req.result || 0);
          req.onerror = () => resolve(0);
        } catch (e) {
          resolve(0);
        }
      });
    };

    const [storiesCount, chaptersCount, segmentsCount, charactersCount, tmCount, pronounRulesCount] = await Promise.all([
      countStore('stories'),
      countStore('chapters'),
      countStore('segments'),
      countStore('characters'),
      countStore('translation_memory'),
      countStore('pronoun_rules'),
    ]);

    // Rough estimate: ~1KB per chapter/segment
    const totalSizeEstimatedKb = Math.round(storiesCount * 5 + chaptersCount * 15 + segmentsCount * 0.5 + tmCount * 0.5);

    return {
      storiesCount,
      chaptersCount,
      segmentsCount,
      charactersCount,
      tmCount,
      pronounRulesCount,
      totalSizeEstimatedKb,
    };
  } catch (err) {
    console.error('Error detecting local data summary:', err);
    return {
      storiesCount: 0,
      chaptersCount: 0,
      segmentsCount: 0,
      charactersCount: 0,
      tmCount: 0,
      pronounRulesCount: 0,
      totalSizeEstimatedKb: 0,
    };
  }
}

export async function exportAllDataAsJSON(): Promise<string> {
  const stories = await getAllStories();
  const db = await openDB();

  const fetchAllFromStore = (name: string): Promise<any[]> => {
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(name, 'readonly');
        const store = tx.objectStore(name);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => resolve([]);
      } catch (e) {
        resolve([]);
      }
    });
  };

  const [chapters, segments, translationMemory, pronounRules, characters, relationships, warnings] = await Promise.all([
    fetchAllFromStore('chapters'),
    fetchAllFromStore('segments'),
    fetchAllFromStore('translation_memory'),
    fetchAllFromStore('pronoun_rules'),
    fetchAllFromStore('characters'),
    fetchAllFromStore('relationships'),
    fetchAllFromStore('warnings'),
  ]);

  const payload = {
    app: 'LanAnhArtistry',
    version: '2.0.0-cloud',
    exportedAt: new Date().toISOString(),
    stats: {
      stories: stories.length,
      chapters: chapters.length,
      segments: segments.length,
      translationMemory: translationMemory.length,
      characters: characters.length,
    },
    data: {
      stories,
      chapters,
      segments,
      translationMemory,
      pronounRules,
      characters,
      relationships,
      warnings,
    },
  };

  return JSON.stringify(payload, null, 2);
}

export async function syncLocalDataToCloud(
  userId: string,
  userName: string,
  onProgress?: (percent: number, currentItem: string) => void
): Promise<{ success: boolean; migratedCounts: Record<string, number> }> {
  try {
    onProgress?.(10, 'Đang quét dữ liệu nội bộ IndexedDB...');
    const stories = await getAllStories();

    onProgress?.(30, 'Đang đồng bộ danh sách truyện...');
    const db = await openDB();

    const fetchAllFromStore = (name: string): Promise<any[]> => {
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(name, 'readonly');
          const store = tx.objectStore(name);
          const req = store.getAll();
          req.onsuccess = () => resolve(req.result || []);
          req.onerror = () => resolve([]);
        } catch (e) {
          resolve([]);
        }
      });
    };

    onProgress?.(50, 'Đang đồng bộ các chương và bộ nhớ dịch thuật...');
    const [chapters, translationMemory] = await Promise.all([
      fetchAllFromStore('chapters'),
      fetchAllFromStore('translation_memory'),
    ]);

    onProgress?.(75, 'Đang đẩy lên máy chủ đám mây...');
    const pushPayload = {
      userId,
      userName,
      stories: stories.map((s) => ({ ...s, ownerId: s.ownerId || userId })),
      chapters,
      translationMemory,
    };

    const res = await fetch('/api/sync/push', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(pushPayload),
    });

    if (!res.ok) {
      throw new Error(`Sync failed with status ${res.status}`);
    }

    onProgress?.(100, 'Đồng bộ đám mây hoàn tất thành công!');
    return {
      success: true,
      migratedCounts: {
        stories: stories.length,
        chapters: chapters.length,
        translationMemory: translationMemory.length,
      },
    };
  } catch (err: any) {
    console.error('syncLocalDataToCloud error:', err);
    throw err;
  }
}

// ==========================================
// STORY FILE ATTACHMENTS (STORY -> FILES)
// ==========================================

export async function getStoryFiles(storyId: string): Promise<StoryFileAttachment[]> {
  const db = await openDB();
  return new Promise((resolve) => {
    try {
      const tx = db.transaction('story_files', 'readonly');
      const store = tx.objectStore('story_files');
      const index = store.index('storyId');
      const req = index.getAll(storyId);
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    } catch {
      resolve([]);
    }
  });
}

export async function saveStoryFile(file: StoryFileAttachment): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction('story_files', 'readwrite');
      const store = tx.objectStore('story_files');
      const req = store.put(file);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    } catch (e) {
      reject(e);
    }
  });
}

export async function deleteStoryFile(fileId: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction('story_files', 'readwrite');
      const store = tx.objectStore('story_files');
      const req = store.delete(fileId);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    } catch (e) {
      reject(e);
    }
  });
}

