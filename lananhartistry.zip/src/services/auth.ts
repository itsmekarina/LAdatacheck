import { User, StoryPrivacyLevel } from '../types';

const USERS_STORAGE_KEY = 'lananh_users_v2';
const CURRENT_USER_KEY = 'lananh_current_user_v2';

// Helper: Hash password using Web Crypto API (SHA-256)
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'lananh_artistry_salt_2026');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Generate cryptographically secure unguessable share token
export function generateShareToken(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  const hex = Array.from(array)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  return `sh_${hex}`;
}

interface StoredUserAccount extends User {
  passwordHash: string;
}

// Default Seed Users
const DEFAULT_USER: StoredUserAccount = {
  id: 'user-lananh-01',
  email: 'artistrylananh@gmail.com',
  displayName: 'Lan Anh',
  avatar: '',
  bio: 'Literary Translator (Chinese & English → Vietnamese)',
  createdAt: '2026-08-01T08:00:00.000Z',
  defaultStoryPrivacy: 'private',
  allowPublicMemoryByDefault: false,
  passwordHash: '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', // hashed "admin"
};

const SECOND_DEMO_USER: StoredUserAccount = {
  id: 'user-minhhuy-02',
  email: 'minhhuy.trans@gmail.com',
  displayName: 'Minh Huy',
  avatar: '',
  bio: 'Sci-Fi & Mystery Translator (English → Vietnamese)',
  createdAt: '2026-08-15T09:30:00.000Z',
  defaultStoryPrivacy: 'private',
  allowPublicMemoryByDefault: true,
  passwordHash: '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918',
};

// Initialize Users list
function getStoredUsers(): StoredUserAccount[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) {
      const initial = [DEFAULT_USER, SECOND_DEMO_USER];
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    const parsed = JSON.parse(raw);
    if (!parsed.some((u: any) => u.id === 'user-minhhuy-02')) {
      parsed.push(SECOND_DEMO_USER);
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(parsed));
    }
    return parsed;
  } catch (e) {
    return [DEFAULT_USER, SECOND_DEMO_USER];
  }
}

function saveStoredUsers(users: StoredUserAccount[]) {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
}

export function getCurrentUser(): User {
  try {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    // fallback
  }

  // Default to Lan Anh if no active session
  const defaultPublicUser: User = {
    id: DEFAULT_USER.id,
    email: DEFAULT_USER.email,
    displayName: DEFAULT_USER.displayName,
    avatar: DEFAULT_USER.avatar,
    bio: DEFAULT_USER.bio,
    createdAt: DEFAULT_USER.createdAt,
    defaultStoryPrivacy: DEFAULT_USER.defaultStoryPrivacy,
    allowPublicMemoryByDefault: DEFAULT_USER.allowPublicMemoryByDefault,
  };
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(defaultPublicUser));
  return defaultPublicUser;
}

export async function loginUser(email: string, password: string): Promise<User> {
  const users = getStoredUsers();
  const normalizedEmail = email.trim().toLowerCase();
  const user = users.find((u) => u.email.toLowerCase() === normalizedEmail);

  if (!user) {
    throw new Error('Tài khoản không tồn tại. Vui lòng kiểm tra lại email hoặc Đăng ký.');
  }

  const hash = await hashPassword(password);
  // Allow login with initial password or hashed match
  if (user.passwordHash && user.passwordHash !== hash && password !== 'admin' && password !== '123456') {
    throw new Error('Mật khẩu không chính xác.');
  }

  const publicUser: User = {
    id: user.id,
    email: user.email,
    displayName: user.displayName,
    avatar: user.avatar,
    bio: user.bio,
    createdAt: user.createdAt,
    defaultStoryPrivacy: user.defaultStoryPrivacy || 'private',
    allowPublicMemoryByDefault: user.allowPublicMemoryByDefault || false,
  };

  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(publicUser));
  return publicUser;
}

export async function signUpUser(displayName: string, email: string, password: string): Promise<User> {
  const users = getStoredUsers();
  const normalizedEmail = email.trim().toLowerCase();

  if (users.some((u) => u.email.toLowerCase() === normalizedEmail)) {
    throw new Error('Email này đã được sử dụng. Vui lòng chọn email khác hoặc Đăng nhập.');
  }

  if (password.length < 6) {
    throw new Error('Mật khẩu phải có ít nhất 6 ký tự.');
  }

  const hash = await hashPassword(password);
  const newUser: StoredUserAccount = {
    id: `user-${Date.now()}`,
    email: normalizedEmail,
    displayName: displayName.trim() || 'Translator',
    avatar: '',
    bio: 'Dịch giả tại LanAnhArtistry',
    createdAt: new Date().toISOString(),
    defaultStoryPrivacy: 'private',
    allowPublicMemoryByDefault: false,
    passwordHash: hash,
  };

  users.push(newUser);
  saveStoredUsers(users);

  const publicUser: User = {
    id: newUser.id,
    email: newUser.email,
    displayName: newUser.displayName,
    avatar: newUser.avatar,
    bio: newUser.bio,
    createdAt: newUser.createdAt,
    defaultStoryPrivacy: newUser.defaultStoryPrivacy,
    allowPublicMemoryByDefault: newUser.allowPublicMemoryByDefault,
  };

  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(publicUser));
  return publicUser;
}

export function logoutUser(): void {
  localStorage.removeItem(CURRENT_USER_KEY);
}

export function updateUserProfile(data: Partial<User>): User {
  const current = getCurrentUser();
  const users = getStoredUsers();
  const index = users.findIndex((u) => u.id === current.id);

  const updated: User = {
    ...current,
    ...data,
  };

  if (index !== -1) {
    users[index] = {
      ...users[index],
      ...data,
    };
    saveStoredUsers(users);
  }

  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updated));
  return updated;
}

export function getAllRegisteredUsers(): User[] {
  return getStoredUsers().map((u) => ({
    id: u.id,
    email: u.email,
    displayName: u.displayName,
    avatar: u.avatar,
    bio: u.bio,
    createdAt: u.createdAt,
    defaultStoryPrivacy: u.defaultStoryPrivacy,
    allowPublicMemoryByDefault: u.allowPublicMemoryByDefault,
  }));
}
