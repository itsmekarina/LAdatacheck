import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, '..', 'data');
const DATA_FILE = path.join(DATA_DIR, 'cloud_store.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export interface CloudStoreData {
  users: Record<string, any>;
  stories: Record<string, any>;
  chapters: Record<string, any>;
  segments: Record<string, any>;
  characters: Record<string, any>;
  pronounRules: Record<string, any>;
  translationMemory: Record<string, any>;
  vocabulary: Record<string, any>;
  terminology: Record<string, any>;
  contributions: Record<string, any>;
  storyBible: Record<string, any>;
  auditLogs: any[];
  lastUpdated: string;
}

const DEFAULT_STORE: CloudStoreData = {
  users: {
    'user-lananh-01': {
      id: 'user-lananh-01',
      email: 'artistrylananh@gmail.com',
      displayName: 'Lan Anh',
      role: 'ADMIN',
      bio: 'Senior Literary Translator (Chinese & English → Vietnamese)',
      createdAt: '2026-01-15T08:00:00Z',
    },
    'user-minhtriet-02': {
      id: 'user-minhtriet-02',
      email: 'minhtriet.translator@gmail.com',
      displayName: 'Minh Triết',
      role: 'USER',
      bio: 'Fantasy & Xianxia Literary Translator',
      createdAt: '2026-02-20T10:30:00Z',
    },
  },
  stories: {},
  chapters: {},
  segments: {},
  characters: {},
  pronounRules: {},
  translationMemory: {
    'tm-sys-01': {
      id: 'tm-sys-01',
      original: '师兄',
      translation: 'sư huynh',
      sourceText: '师兄',
      targetText: 'sư huynh',
      language: 'zh',
      context: 'Đồng môn nam nhập môn trước, kính xưng thân mật hoặc trang trọng',
      genre: 'xianxia/cultivation',
      speakerGender: 'any',
      relationshipContext: 'sư muội/sư đệ gọi sư huynh',
      frequency: 480,
      usageCount: 480,
      contributorCount: 12,
      confidenceScore: 0.99,
      sourceType: 'SYSTEM',
      createdBy: 'user-lananh-01',
      status: 'approved',
      preferred: true,
      category: 'title',
      firstChapter: 1,
      lastChapter: 999,
      chapterIds: [1, 2, 3],
      notes: 'Thuật ngữ nền tảng văn học tiên hiệp/kiếm hiệp.',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    },
    'tm-sys-02': {
      id: 'tm-sys-02',
      original: '师尊',
      translation: 'sư tôn',
      sourceText: '师尊',
      targetText: 'sư tôn',
      language: 'zh',
      context: 'Đệ tử gọi ân sư, tôn xưng tối thượng trong môn phái',
      genre: 'xianxia/cultivation',
      frequency: 395,
      usageCount: 395,
      contributorCount: 8,
      confidenceScore: 0.98,
      sourceType: 'SYSTEM',
      status: 'approved',
      preferred: true,
      category: 'title',
      firstChapter: 1,
      lastChapter: 999,
      chapterIds: [1, 2],
      notes: 'Tránh dịch thành thầy/sư phụ khi trong bối cảnh tông môn trang nghiêm.',
      createdAt: '2026-01-01T00:00:00Z',
    },
    'tm-sys-03': {
      id: 'tm-sys-03',
      original: '宗门',
      translation: 'tông môn',
      sourceText: '宗门',
      targetText: 'tông môn',
      language: 'zh',
      context: 'Môn phái tu tiên',
      genre: 'xianxia',
      frequency: 240,
      usageCount: 240,
      contributorCount: 6,
      confidenceScore: 0.97,
      sourceType: 'SYSTEM',
      status: 'approved',
      preferred: true,
      category: 'organization',
      firstChapter: 1,
      lastChapter: 999,
      chapterIds: [1],
      notes: 'Thống nhất dùng tông môn thay vì bang phái trong tiên hiệp.',
      createdAt: '2026-01-01T00:00:00Z',
    },
    'tm-sys-04': {
      id: 'tm-sys-04',
      original: '白月光',
      translation: 'ánh trăng sáng',
      sourceText: '白月光',
      targetText: 'ánh trăng sáng',
      language: 'zh',
      context: 'Hình bóng người yêu lý tưởng trong lòng không thể chạm tới',
      genre: 'romance/modern',
      frequency: 185,
      usageCount: 185,
      contributorCount: 5,
      confidenceScore: 0.95,
      sourceType: 'COMMUNITY',
      status: 'approved',
      preferred: true,
      category: 'expression',
      firstChapter: 1,
      lastChapter: 999,
      chapterIds: [],
      notes: 'Từ lóng văn học mạng thịnh hành.',
      createdAt: '2026-01-10T00:00:00Z',
    },
  },
  vocabulary: {
    'vocab-01': {
      id: 'vocab-01',
      term: '白月光',
      language: 'zh',
      meaning: 'Người yêu trong mộng, người hoàn hảo nhưng không với tới được',
      pronunciation: 'bái yuè guāng',
      pinyin: 'bái yuè guāng',
      preferredTranslation: 'ánh trăng sáng',
      alternativeTranslations: ['người trong lòng', 'mối tình đầu khó phai'],
      context: 'Văn học ngôn tình, hiện đại lẫn cổ trang',
      notes: 'Thường đặt đối lập với Chu Sa Chí (nốt chu sa).',
      usageCount: 312,
      contributorCount: 9,
      status: 'approved',
      sourceType: 'SYSTEM',
      createdBy: 'user-lananh-01',
      createdAt: '2026-01-05T00:00:00Z',
      updatedAt: '2026-01-05T00:00:00Z',
    },
    'vocab-02': {
      id: 'vocab-02',
      term: '朱砂痣',
      language: 'zh',
      meaning: 'Vết son đỏ, tình cảm khắc cốt ghi tâm nhưng để lỡ',
      pronunciation: 'zhū shā zhì',
      pinyin: 'zhū shā zhì',
      preferredTranslation: 'nốt chu sa',
      alternativeTranslations: ['vết chu sa trong tim'],
      context: 'Thành ngữ văn học lãng mạn',
      notes: 'Xuất phát từ văn hào Trương Ái Linh.',
      usageCount: 198,
      contributorCount: 5,
      status: 'approved',
      sourceType: 'SYSTEM',
      createdBy: 'user-lananh-01',
      createdAt: '2026-01-05T00:00:00Z',
      updatedAt: '2026-01-05T00:00:00Z',
    },
    'vocab-03': {
      id: 'vocab-03',
      term: '道侣',
      language: 'zh',
      meaning: 'Bạn đồng hành tu đạo kết làm phu thê',
      pronunciation: 'dào lǚ',
      pinyin: 'dào lǚ',
      preferredTranslation: 'đạo lữ',
      alternativeTranslations: ['bạn đồng tu'],
      context: 'Tiên hiệp, tu chân thế giới',
      notes: 'Dùng như danh từ chỉ bạn đời của người tu sĩ.',
      usageCount: 420,
      contributorCount: 11,
      status: 'approved',
      sourceType: 'SYSTEM',
      createdBy: 'user-lananh-01',
      createdAt: '2026-01-02T00:00:00Z',
      updatedAt: '2026-01-02T00:00:00Z',
    },
  },
  terminology: {
    'term-01': {
      id: 'term-01',
      term: '魔尊',
      preferredTranslation: 'Ma Tôn',
      alternativeTranslations: ['Ma Tôn đại nhân', 'Chúa tể ma giới'],
      category: 'title',
      context: 'Xưng hiệu chí tôn của người đứng đầu Ma Vực/Ma Giới',
      notes: 'Nên viết hoa danh xưng trang trọng.',
      usageCount: 560,
      status: 'approved',
      sourceType: 'SYSTEM',
      createdBy: 'user-lananh-01',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    },
    'term-02': {
      id: 'term-02',
      term: '元婴期',
      preferredTranslation: 'Nguyên Anh kỳ',
      alternativeTranslations: ['Cảnh giới Nguyên Anh'],
      category: 'cultivation',
      context: 'Cảnh giới tu tiên sau Kim Đan, trước Hóa Thần',
      notes: 'Thống nhất chuẩn hệ thống tu tiên cổ điển.',
      usageCount: 710,
      status: 'approved',
      sourceType: 'SYSTEM',
      createdBy: 'user-lananh-01',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    },
    'term-03': {
      id: 'term-03',
      term: '万剑峰',
      preferredTranslation: 'Vạn Kiếm Phong',
      alternativeTranslations: ['Đỉnh Vạn Kiếm'],
      category: 'location',
      context: 'Ngọn núi chính nơi kiếm tu luyện kiếm',
      notes: 'Địa danh tông môn.',
      usageCount: 142,
      status: 'approved',
      sourceType: 'SYSTEM',
      createdBy: 'user-lananh-01',
      createdAt: '2026-01-03T00:00:00Z',
      updatedAt: '2026-01-03T00:00:00Z',
    },
  },
  contributions: {
    'contrib-demo-01': {
      id: 'contrib-demo-01',
      contributorId: 'user-minhtriet-02',
      contributorName: 'Minh Triết',
      contributionType: 'terminology',
      original: '灵墟',
      proposedValue: 'Linh Khư',
      reason: 'Bí cảnh tàn tích tiên cổ phổ biến trong các bộ truyện tu chân mới',
      evidence: 'Đã xuất hiện và sử dụng ổn định qua 3 tác phẩm tiên hiệp ăn khách',
      status: 'PENDING',
      sourceStoryId: '',
      sourceStoryTitle: 'Kiếm Đạo Độc Tôn',
      createdAt: '2026-03-01T14:20:00Z',
    },
    'contrib-demo-02': {
      id: 'contrib-demo-02',
      contributorId: 'user-minhtriet-02',
      contributorName: 'Minh Triết',
      contributionType: 'translation_memory',
      original: '师尊在上，请受徒儿一拜',
      proposedValue: 'Sư tôn tại thượng, xin nhận một lạy của đồ nhi',
      reason: 'Mẫu câu bái sư/hành lễ trang nghiêm lặp lại thường xuyên',
      evidence: 'Xuất hiện trong các chương bái sư của Tiên Đạo Quy Nguyên',
      status: 'APPROVED',
      reviewedBy: 'user-lananh-01',
      reviewedAt: '2026-03-02T09:15:00Z',
      sourceStoryTitle: 'Tiên Đạo Quy Nguyên',
      createdAt: '2026-03-01T16:00:00Z',
    },
  },
  storyBible: {},
  auditLogs: [
    {
      id: 'audit-init-01',
      userId: 'user-lananh-01',
      userName: 'Lan Anh',
      action: 'SYSTEM_INIT',
      entityType: 'DATABASE',
      entityId: 'root',
      details: { message: 'Khởi tạo Cloud Translation Knowledge Base cho LanAnhArtistry' },
      createdAt: '2026-01-01T00:00:00Z',
    },
  ],
  lastUpdated: new Date().toISOString(),
};

export class CloudStore {
  private data: CloudStoreData;

  constructor() {
    this.data = this.load();
  }

  private load(): CloudStoreData {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return { ...DEFAULT_STORE, ...parsed };
      }
    } catch (e) {
      console.error('Failed to load cloud_store.json, using defaults:', e);
    }
    this.save(DEFAULT_STORE);
    return DEFAULT_STORE;
  }

  private save(data?: CloudStoreData) {
    try {
      const target = data || this.data;
      target.lastUpdated = new Date().toISOString();
      fs.writeFileSync(DATA_FILE, JSON.stringify(target, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write cloud_store.json:', e);
    }
  }

  public getData(): CloudStoreData {
    return this.data;
  }

  public getStoriesForUser(userId: string, isAdmin = false) {
    const all = Object.values(this.data.stories);
    if (isAdmin) return all;
    return all.filter((s: any) => s.ownerId === userId || s.privacy === 'public' || s.visibility === 'PUBLIC' || s.sourceType === 'SYSTEM');
  }

  public saveStories(stories: any[], userId: string, userName?: string) {
    for (const story of stories) {
      this.data.stories[story.id] = {
        ...story,
        ownerId: story.ownerId || userId,
        ownerName: story.ownerName || userName || 'Translator',
        updatedAt: new Date().toISOString(),
      };
    }
    this.save();
    this.logAudit(userId, userName || 'User', 'SAVE_STORIES', 'story', `${stories.length} stories`, { count: stories.length });
    return true;
  }

  public saveChapters(chapters: any[], userId: string) {
    for (const ch of chapters) {
      this.data.chapters[ch.id] = {
        ...ch,
        updatedAt: new Date().toISOString(),
      };
    }
    this.save();
    return true;
  }

  public saveTranslationMemory(items: any[], userId: string) {
    for (const item of items) {
      this.data.translationMemory[item.id] = {
        ...item,
        updatedAt: new Date().toISOString(),
      };
    }
    this.save();
    return true;
  }

  public saveVocabulary(items: any[], userId: string) {
    for (const item of items) {
      this.data.vocabulary[item.id] = {
        ...item,
        updatedAt: new Date().toISOString(),
      };
    }
    this.save();
    return true;
  }

  public saveTerminology(items: any[], userId: string) {
    for (const item of items) {
      this.data.terminology[item.id] = {
        ...item,
        updatedAt: new Date().toISOString(),
      };
    }
    this.save();
    return true;
  }

  public addContribution(contribution: any, userId: string, userName: string) {
    const id = contribution.id || `contrib-${Date.now()}`;
    const entry = {
      ...contribution,
      id,
      contributorId: userId,
      contributorName: userName,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
    };
    this.data.contributions[id] = entry;
    this.save();
    this.logAudit(userId, userName, 'SUBMIT_CONTRIBUTION', 'contribution', id, { type: contribution.contributionType, original: contribution.original });
    return entry;
  }

  public reviewContribution(id: string, decision: 'APPROVED' | 'REJECTED' | 'MERGE', reviewerId: string, reviewerName: string, notes?: string) {
    const target = this.data.contributions[id];
    if (!target) return null;

    target.status = decision === 'MERGE' ? 'APPROVED' : decision;
    target.reviewedBy = reviewerId;
    target.reviewedAt = new Date().toISOString();

    // If approved, integrate into translation memory, vocabulary, or terminology!
    if (decision === 'APPROVED' || decision === 'MERGE') {
      if (target.contributionType === 'translation_memory') {
        const tmId = `tm-comm-${Date.now()}`;
        this.data.translationMemory[tmId] = {
          id: tmId,
          original: target.original,
          translation: target.proposedValue,
          sourceText: target.original,
          targetText: target.proposedValue,
          language: 'zh',
          context: target.reason || 'Được duyệt từ đóng góp cộng đồng',
          sourceType: 'COMMUNITY',
          status: 'approved',
          preferred: true,
          frequency: 1,
          usageCount: 1,
          contributorCount: 1,
          confidenceScore: 0.96,
          createdBy: target.contributorId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          firstChapter: 1,
          lastChapter: 999,
          chapterIds: [],
          notes: target.evidence || '',
        };
      } else if (target.contributionType === 'terminology') {
        const termId = `term-comm-${Date.now()}`;
        this.data.terminology[termId] = {
          id: termId,
          term: target.original,
          preferredTranslation: target.proposedValue,
          category: 'general',
          context: target.reason || '',
          notes: target.evidence || '',
          usageCount: 1,
          status: 'approved',
          sourceType: 'COMMUNITY',
          createdBy: target.contributorId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
      } else if (target.contributionType === 'vocabulary') {
        const vocabId = `vocab-comm-${Date.now()}`;
        this.data.vocabulary[vocabId] = {
          id: vocabId,
          term: target.original,
          language: 'zh',
          meaning: target.reason || '',
          preferredTranslation: target.proposedValue,
          notes: target.evidence || '',
          usageCount: 1,
          contributorCount: 1,
          status: 'approved',
          sourceType: 'COMMUNITY',
          createdBy: target.contributorId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
      }
    }

    this.save();
    this.logAudit(reviewerId, reviewerName, `REVIEW_CONTRIBUTION_${decision}`, 'contribution', id, { targetOriginal: target.original, decision, notes });
    return target;
  }

  public logAudit(userId: string, userName: string, action: string, entityType: string, entityId: string, details: any) {
    const entry = {
      id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      userId,
      userName,
      action,
      entityType,
      entityId,
      details,
      createdAt: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(entry);
    // Keep max 500 logs
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
    this.save();
    return entry;
  }

  public searchKnowledge(query: string, category?: string, source?: string) {
    const q = query.toLowerCase().trim();
    if (!q) {
      return {
        translationMemory: Object.values(this.data.translationMemory).slice(0, 20),
        vocabulary: Object.values(this.data.vocabulary).slice(0, 20),
        terminology: Object.values(this.data.terminology).slice(0, 20),
      };
    }

    const matchesTM = Object.values(this.data.translationMemory).filter((item: any) => {
      const matchText = (item.original || '').toLowerCase().includes(q) ||
        (item.translation || '').toLowerCase().includes(q) ||
        (item.context || '').toLowerCase().includes(q);
      const matchSource = !source || source === 'all' || item.sourceType === source;
      return matchText && matchSource;
    });

    const matchesVocab = Object.values(this.data.vocabulary).filter((item: any) => {
      const matchText = (item.term || '').toLowerCase().includes(q) ||
        (item.preferredTranslation || '').toLowerCase().includes(q) ||
        (item.meaning || '').toLowerCase().includes(q) ||
        (item.pinyin || '').toLowerCase().includes(q);
      return matchText;
    });

    const matchesTerm = Object.values(this.data.terminology).filter((item: any) => {
      const matchText = (item.term || '').toLowerCase().includes(q) ||
        (item.preferredTranslation || '').toLowerCase().includes(q) ||
        (item.context || '').toLowerCase().includes(q);
      const matchCat = !category || category === 'all' || item.category === category;
      return matchText && matchCat;
    });

    return {
      translationMemory: matchesTM,
      vocabulary: matchesVocab,
      terminology: matchesTerm,
    };
  }

  public getDashboardStats() {
    const storiesList = Object.values(this.data.stories);
    const chaptersList = Object.values(this.data.chapters);
    const tmList = Object.values(this.data.translationMemory);
    const vocabList = Object.values(this.data.vocabulary);
    const termList = Object.values(this.data.terminology);
    const contribList = Object.values(this.data.contributions);

    return {
      totalStories: storiesList.length,
      userStories: storiesList.filter((s: any) => s.sourceType === 'USER').length,
      systemStories: storiesList.filter((s: any) => s.sourceType === 'SYSTEM').length,
      totalChapters: chaptersList.length,
      totalTranslationMemory: tmList.length,
      totalVocabulary: vocabList.length,
      totalTerminology: termList.length,
      totalCharacters: Object.keys(this.data.characters).length,
      totalPronounRules: Object.keys(this.data.pronounRules).length,
      totalContributions: contribList.length,
      pendingContributions: contribList.filter((c: any) => c.status === 'PENDING').length,
      approvedContributions: contribList.filter((c: any) => c.status === 'APPROVED').length,
      auditLogsCount: this.data.auditLogs.length,
      lastSyncTimestamp: this.data.lastUpdated,
    };
  }
}

export const cloudStore = new CloudStore();
